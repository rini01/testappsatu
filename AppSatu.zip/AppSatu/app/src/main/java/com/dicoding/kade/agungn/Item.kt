package kade.dicoding.com.appsatu

/**
 * Created by admin on 20-Oct-18.
 */

data class Item (val name: String?, val image: Int?, val detail: String?)

